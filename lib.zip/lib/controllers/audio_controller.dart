import 'package:get/get.dart';

class AudioController extends GetxController {
  RxBool isPLaying = false.obs;
  RxBool isLoading = false.obs;
}